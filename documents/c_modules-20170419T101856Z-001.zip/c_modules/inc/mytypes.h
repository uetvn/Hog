/*******************************************************************************
// Project name   :
// File name      : mytypes.h
// Created date   : Tue 28 Jun 2016 02:28:10 PM ICT
// Author         : Ngoc-Sinh Nguyen
// Last modified  : Thu 13 Apr 2017
// Desc           :
*******************************************************************************/

#ifndef MYTYPES
#define MYTYPES

typedef int                  int32;
typedef unsigned int         uint32;
typedef unsigned int         uint;
typedef short                int16;
typedef unsigned short       uint16;
typedef char                 int8;
typedef unsigned char        uint8;
#endif
